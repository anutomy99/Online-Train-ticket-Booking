package com.feathersoft.trainingproject.OnlineTrainTicketBooking.dto;

public enum PaymentStatus {
    PENDING,
    FAILED,
    PAID,
    REFUNDED
}
