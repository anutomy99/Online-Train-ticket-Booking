package com.feathersoft.trainingproject.OnlineTrainTicketBooking.dto;

import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import javax.net.ssl.KeyManager;

@Component
public class CardNumberEncryptionUtil {

}
